
This directory contains files that are useful to the library developer.

It contains the source for the documentation, some performance testing
scripts and some release utilities.

