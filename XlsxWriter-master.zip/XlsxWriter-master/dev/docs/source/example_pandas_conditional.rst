.. _ex_pandas_conditional:

Example: Pandas Excel output with conditional formatting
========================================================

An example of converting a Pandas dataframe to an Excel file with a
conditional formatting using Pandas and XlsxWriter.

.. image:: _images/pandas_conditional.png

.. literalinclude:: ../../../examples/pandas_conditional_format.py
