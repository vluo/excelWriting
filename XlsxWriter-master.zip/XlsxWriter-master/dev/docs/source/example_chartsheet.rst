.. _ex_chartsheet:

Example: Chartsheet
===================

Example of creating an Excel Bar chart on a :ref:`chartsheet <Chartsheet>`.

.. image:: _images/chartsheet.png

.. literalinclude:: ../../../examples/chartsheet.py
